SYSTEM//FIELD GitHub Pages package

Upload ALL files in this folder to the ROOT of your GitHub Pages repository.

Main flow:
index.html -> intake.html -> review.html -> checkout.html
index.html -> examples.html -> individual project pages

Important:
The checkout page is still a front-end prototype. It does not process real payments.
Use Stripe Checkout / Payment Element or Square Web Payments SDK before accepting real card details.
